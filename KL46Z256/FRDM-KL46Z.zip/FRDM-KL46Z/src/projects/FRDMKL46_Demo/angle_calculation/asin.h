
/* asin.h
 
  determine degree from 0 to 900 arc sin
  lookup table for arc sin function for 
  128 values return degrees from 0 to 900
  
*/
extern const int myasin[];
