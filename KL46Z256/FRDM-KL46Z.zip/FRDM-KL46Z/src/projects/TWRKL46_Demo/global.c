
#include "common.h"

uint16 pit1_isrv_count;
uint16 base_time125m;

uint16 ti_task;

uint16 ti_fall;
uint16 ti_accel_sampling;
uint16 ti_delay;
uint16 ti_print;
uint16 ti_console;
uint16 ti_led;
uint16 ti_tsi0;
uint16 ti_tsi1;
uint16 ti_test_adc;
uint16 adc_sample;
uint16 rtc_seconds_isrv_count;
uint16 ti_tsi_multiplexing;