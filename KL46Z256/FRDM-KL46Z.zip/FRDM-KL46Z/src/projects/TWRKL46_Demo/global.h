
#include "common.h"

extern uint16 pit1_isrv_count;
extern uint16 base_time125m;
extern uint16 ti_task;


extern uint16 ti_fall;
extern uint16 ti_accel_sampling;
extern uint16 ti_delay;
extern uint16 ti_led;
extern uint16 ti_tsi0;
extern uint16 ti_tsi1;
extern uint16 ti_test_adc;
extern uint16 adc_sample;
extern uint16 ti_print;
extern uint16 ti_console;
extern uint16 rtc_seconds_isrv_count;
extern uint16 ti_tsi_multiplexing;

