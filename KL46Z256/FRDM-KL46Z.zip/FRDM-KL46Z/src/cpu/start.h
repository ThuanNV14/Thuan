/*
 * File:	start.h
 * Purpose:	Kinetis L Family start up routines. 
 *
 * Notes:		
 */


// Function prototypes
void start(void);
void cpu_identify(void);
void flash_identify(void);
